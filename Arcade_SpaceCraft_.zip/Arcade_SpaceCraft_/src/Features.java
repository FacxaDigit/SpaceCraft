import java.awt.Canvas;
import java.awt.Dimension; //|Creazione finestra| Per la dimensione della finestra
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import javax.swing.JFrame; //|Creazione finestra| Nome alla finestra

public class Features extends Canvas implements KeyListener, Runnable {
	
	private static final int Lenght = 1920;
	private static final int Hight = 1080;
	
	private static final String NameGame = " ArcadeSpaceCraft ";
	
	private boolean gameRunning = false;
	
	//
	private SpaceCraft spaceCraft;
	//
	
	BufferedImage background = null;
	BufferedImage SpaceCraft = null;
	BufferedImage LaserWeapon = null;
	
	public Features () {
		SourceLoader();
		startGame();
	}

	public static void main(String[] args) {
		
		Features game = new Features();
		
		JFrame windowsGame = new JFrame(NameGame);
		Dimension WindowSize = new Dimension(Lenght, Hight);
		windowsGame.setPreferredSize(WindowSize);
		windowsGame.setMaximumSize(WindowSize);
		windowsGame.setResizable(false);	
		
		windowsGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		windowsGame.add(game);
		windowsGame.addKeyListener(game);
		
		windowsGame.pack();
		windowsGame.setVisible(true);
		//Creazione thread v
		Thread threadGame = new Thread(game);
		threadGame.start();//Starta il metodo "run" 
		
	}
	
	private void startGame () {
		spaceCraft = new SpaceCraft(SpaceCraft, 128, 160, 10, 800);
		spaceCraft.start();
	}
	
	private void SourceLoader() {
		ImageLoader loader = new ImageLoader();
		background = loader.LoadImage("/Image/SpazioGame.png");
		SpaceCraft = loader.LoadImage("/Image/NavicellaArcade.png");
		System.out.println("Risorse caricate!");
	}
	private void Draw() {
		BufferStrategy buffer = this.getBufferStrategy();
		if(buffer == null) {
			createBufferStrategy(2);
			return;
		}
		Graphics g = buffer.getDrawGraphics();
		
		g.drawImage(background, 0, 0, Lenght, Hight, this);
		
		spaceCraft.Draw(g);
		
		g.dispose();
		buffer.show();
	}
	
	///////////////////////////////////////////////////////////////////////
	@Override
	public void run() {
		// TODO Auto-generated method stub
		gameRunning = true;
		
		while(gameRunning) {
			Draw();
		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	////////////////////////////////////////////
	public int MaxRandom (int varMin, int varMax) {
		int rand = (int) (Math.random() * ((varMax-varMin)+1)) + varMin;
		System.out.println(" Rand = " + rand);
		
        return rand;
	}


}
