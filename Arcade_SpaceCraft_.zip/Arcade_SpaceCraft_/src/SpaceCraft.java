import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.lang.System.Logger.Level;
import java.util.logging.Logger;

public class SpaceCraft extends Thread {
	
	private int posX;
	private int posY;
	
	private int lenght;
	private int hight;
	
	private boolean active;
	
	BufferedImage imgSpaceCraft;

	public SpaceCraft(BufferedImage image, int lenght, int hight, int posX, int posY) {
		// TODO Auto-generated constructor stub
		this.posX = posX;
		this.posY = posY;
		this.lenght = lenght;
		this.hight = hight;
		this.imgSpaceCraft = image;
		active = true;
	}
	@Override
	public void run() {
		active=true;
		while(active) {
			update();
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	public void update () {
		//L'oggetto si muove
		posX++;
	}
	
	public void Draw (Graphics g) {
		g.drawImage(imgSpaceCraft, posX, posY, lenght, hight, null);
	}

}
