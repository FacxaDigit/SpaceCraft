import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.lang.System.Logger.Level;
import java.util.logging.Logger;

public class SpaceCraft extends Thread {
	private int [] prova = new int [2];
	private int contatore;
	private int mill;
	
	private boolean shoot = false;
	
	
	private int posX;
	private int posY;
	
	protected int lenght;
	private int hight;
	
	private boolean active;	
	private int step = 10;
	
	BufferedImage imgSpaceCraft;
	
	//da mettere in seguito all'interno del caricamento risorse della classe Features
	ImageLoader loader = new ImageLoader();
	BufferedImage Magenta = loader.LoadImage("/Image/Magenta.png");
	BufferedImage Yellow = loader.LoadImage("/Image/Yellow1.png");
	/////////////////////////////////////////////////////////////////////////////////
	
	Features PropWind;
	
	public SpaceCraft() {}
	public SpaceCraft(BufferedImage image, int lenght, int hight, int posX, int posY, Features PropWind/*, boolean shoot*/) {
		// TODO Auto-generated constructor stub
		this.posX = posX;
		this.posY = posY;
		this.lenght = lenght;
		this.hight = hight;
		this.imgSpaceCraft = image;
		//active = true;
		this.PropWind = PropWind;
		
		//this.shoot = shoot;
	}
	
	public void Draw (Graphics g) {
		//
		mill++;
		if(mill>50) {
			mill=0;
			contatore++;
		}
		prova[1]=posX;
		g.drawImage(imgSpaceCraft, posX, (PropWind.getHight())-((PropWind.getHight()/8)*2), lenght, hight, null);
		g.setColor(Color.yellow);
		g.fillRect(prova[0]+60, posY+150, 3, 3);

		g.drawImage(Magenta, prova[0]+56, (PropWind.getHight())-((PropWind.getHight()/8)*2) + 85, 7, 7, null);
		g.drawImage(Magenta, prova[0]+64, (PropWind.getHight())-((PropWind.getHight()/8)*2) + 85, 7, 7, null);
		g.drawImage(Yellow, prova[0]+46, (PropWind.getHight())-((PropWind.getHight()/8)*2)+ 89, 6, 7, null);
		g.drawImage(Yellow, prova[0]+75, (PropWind.getHight())-((PropWind.getHight()/8)*2) + 89, 6, 7, null);
		
		if(contatore>1) {
			prova[0]=prova[1];
			contatore=0;
		}

		
	}
	
	//---------------------------------------------------------------------------------- Set and get
	public int getPosX() {
		return posX;
	}
	public void setPosX(int posX) {
		this.posX = posX;
	}
	public int getPosY() {
		return posY;
	}
	public void setPosY(int posY) {
		this.posY = posY;
	}
	public int getLenght() {
		return lenght;
	}
	public void setLenght(int lenght) {
		this.lenght = lenght;
	}
	public int getHight() {
		return hight;
	}
	public void setHight(int hight) {
		this.hight = hight;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	//----------------------------------------------------------------------------------
	
	public void stepToRight() {
		if((posX+lenght)<PropWind.getLenght()) {
			posX+=step;
			System.out.println("Destra");
		}
		
	}
	public void stepToLeft() {
		if(posX>0) {
			posX-=step;
			System.out.println("Sinistra");
		}
		
	}
	public void shoot() {
		
	}

}
