import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImage;
import java.lang.System.Logger.Level;
import java.util.logging.Logger;

public class Star extends Thread {

	private int spostamento = 0;
	private int spost = 0;
	private boolean StarBackG = true;
	
	Features PropWind;
	
	private int dim;
	private int num;
	private int range;
	
	private int varX[] = new int[450];
	private int varY[] = new int[450];

	//private Graphics g;
	
	//BufferedImage Star;
	
	public Star() {}
	public Star(/*BufferedImage Star,*/ int dim, int num, int range, Features PropWind/*, int[] varX, int[] varY*/) {
		super();
		//this.Star = Star;
		this.dim = dim;
		this.num = num;
		this.range = range;
		this.PropWind = PropWind;
		//this.varX = varX;
		//this.varY = varY;
	}
	
    public int NumRandom (int varMin, int varMax) {
		int rand = (int) (Math.random() * ((varMax-varMin)+1)) + varMin;
		System.out.println(" Rand = " + rand + " num = " + num + " varMin = " + varMin + " varMax = " + varMax);
		
        return rand;
    }
    
    
	public void GenerateStarBG () {
		for(int k=0; k<num; k++) {
			varX[k] = NumRandom(PropWind.getLenght(), 0);
			varY[k] = NumRandom(PropWind.getHight(), 0);
			System.out.println("Generazione stelle");
		}
		
	}
	
	public void DrawStar(Graphics g) {
		spostamento++;
		if(spostamento>10) {
			spost++;
			spostamento=0;
		}
		
		g.setColor(Color.white);
		/*try {
			Thread.sleep(0);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
    	for(int k=0; k<num; k++) {
    			g.fillRect(varX[k], varY[k] + spost, 3, 3);
    			//System.out.println("spost = " + spost);
			//System.out.println("Disegno stelle  X = " + varX[k] + " Y = "+ varY[k]);
    	}
    	for(int k=0; k<num; k++) {
			g.fillRect(varX[k], varY[k] - (PropWind.getHight() - spost), 3, 3);
		//System.out.println("Disegno stelle  X = " + varX[k] + " Y = "+ varY[k]);
    	}
    	spostamento++;
    	if(spost>PropWind.getHight()) {
    		spost=0;
    	}
    	//System.out.println(" spost = " + spost);
	}
	
	
	
	
	
	
	
	
	

}
