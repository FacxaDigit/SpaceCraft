import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImage;
import java.lang.System.Logger.Level;
import java.util.logging.Logger;

public class CompStars extends Thread {
	
	private Star [] compStars;


	int timer = 0;
	int advance = 0;
	boolean StarBackG = true;
	//private int range;
	
	Features PropWind;
	
	
	
	public CompStars() {}
	
	public CompStars(int NElements) {
		compStars = new Star[NElements];
		
		for(int k=0; k<compStars.length; k++) {
			compStars[k] = new Star();
		}
	}
	
	public CompStars(CompStars a) {
		compStars = new Star[a.getCompStars().length];
		
		for(int k=0; k<compStars.length; k++) {
			compStars[k] = a.getCompStars()[k];
		}
	}
	
	public Star[] getCompStars() {
		return compStars;
	}
	public void setCompStars(Star[] compStars) {
		this.compStars = compStars;
	}
	
    public int NumRandom (int varMin, int varMax) {
		int rand = (int) (Math.random() * ((varMax-varMin)+1)) + varMin;
		//System.out.println(" Rand = " + rand + " num = " + num + " varMin = " + varMin + " varMax = " + varMax);
		
        return rand;
    }
    
    
	public void GenerateStarBG () {
		for(int k=0; k<compStars.length; k++) {
			compStars[k].setVarX(NumRandom(0, Features.getLenght()));
			compStars[k].setVarY(NumRandom(0, Features.getHight()));
			
			compStars[k].setDim(NumRandom(2, 4));
			compStars[k].setColor(NumRandom(0, 5));
			
			System.out.println("Generazione stelle");
		}
		
	}
	public void DrawStar(Graphics g) {
		if(advance>1080) {
			advance=0;
			//GenerateStarBG();
		}
		timer++;
		if(timer>10) {
			advance++;
			timer=0;
		}
	
		//System.out.println(" advance = "+ advance);
		
    	for(int k=0; k<compStars.length; k++) {
    			
    			if(compStars[k].getColor() == 0) { //Poi metter� switch
    				g.setColor(Color.magenta);
    			}
    			else if(compStars[k].getColor() == 1) {
    				g.setColor(Color.blue);
    			}
    			else {
    				g.setColor(Color.white);
    			}
    			
    			g.fillRect(compStars[k].getVarX(), compStars[k].getVarY() + advance, compStars[k].getDim()+2, compStars[k].getDim());

    	}
    	for(int k=0; k<compStars.length; k++) {
    		
    		if(compStars[k].getColor() == 0) { //Poi metter� switch
				g.setColor(Color.magenta);
			}
			else if(compStars[k].getColor() == 1) {
				g.setColor(Color.blue);
			}
			else {
				g.setColor(Color.white);
			}
			
    		
			g.fillRect(compStars[k].getVarX(), compStars[k].getVarY() - (PropWind.getHight() - advance), compStars[k].getDim()+2, compStars[k].getDim());
		
    	}

	}
}
