import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension; //|Creazione finestra| Per la dimensione della finestra
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.JFrame; //|Creazione finestra| Nome alla finestra

public class Features extends Canvas implements KeyListener, MouseMotionListener, Runnable {
	
	////////////////////////////////////////////////////////////Window
	private static final int Lenght = 1920;
	private static final int Hight = 1080;
	
	private static final String NameGame = " ArcadeSpaceCraft ";
	//----------------------------------------------------------
	
	private boolean gameRunning = false; //Game state
	
	//
	private Counter counter;
	private SpaceCraft spaceCraft;
	private LaserWeapon laserWeapon;
	private CompStars compStars;
	//private Star star2;
	private boolean shot=false;
	//
	//{
	BufferedImage background = null;
	BufferedImage SpaceCraft = null;
	BufferedImage SpaceCraft_Wake = null;
	//BufferedImage Star = null;
	BufferedImage LaserWeapon = null;
	
	File file = null;//audio
	//}
	
	public Features () {
		SourceLoader();
		startGame();
	}
	//******************************************************************************
	public static void main(String[] args) {
		
		Features game = new Features();
		
		JFrame windowsGame = new JFrame(NameGame);
		Dimension WindowSize = new Dimension(Lenght, Hight);
		windowsGame.setPreferredSize(WindowSize);
		windowsGame.setMaximumSize(WindowSize);
		windowsGame.setResizable(false);	
		
		windowsGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		windowsGame.add(game);
		windowsGame.addKeyListener(game);
		game.addMouseMotionListener(game);
		
		windowsGame.pack();
		windowsGame.setVisible(true);

		Thread threadGame = new Thread(game); //Creazione thread
		threadGame.start();//Starta il metodo "run" 
		
	}
	//******************************************************************************
    public int NumRandom (int varMin, int varMax) {
		int rand = (int) (Math.random() * ((varMax-varMin)+1)) + varMin;
		System.out.println(" Rand = " + rand);
		
        return rand;
    }
	
	public static int getLenght() {
		return Lenght;
	}

	public static int getHight() {
		return Hight;
	}

	private void startGame () {
		counter = new Counter(1000, 10);
		counter.start();
		
		spaceCraft = new SpaceCraft(SpaceCraft, 128, 160, 0, 800, this);//Pos x viene dato dall'input
		//spaceCraft_Wake = new spaceCe
		spaceCraft.start();
		
		compStars = new CompStars(200);
		compStars.GenerateStarBG();
		
		laserWeapon = new LaserWeapon(600, 600, this);
		//star.start();
		
	}
	
	private void SourceLoader() {
		//immagini
		try {
			ImageLoader loader = new ImageLoader(); //Per caricare le immagini -> utilizzo buffer
			background = loader.LoadImage("/Image/SpazioGame.png");
			SpaceCraft = loader.LoadImage("/Image/NavicellaArcade.png");
			
			//audio
			file = new File("Level_Up.wav"); //Non funzionante al momento
			
			System.out.println(" Risorse caricate! ");
		}
		catch (Exception e) {
			System.out.println(" Risorse non caricate -ERRORE- ");
		}
  
	}
	private void Draw() {//3
		BufferStrategy buffer = this.getBufferStrategy();
		if(buffer == null) {
			createBufferStrategy(2);
			return;
		}
		Graphics g = buffer.getDrawGraphics();
		
		g.drawImage(background, 0, 0, Lenght, Hight, this);
		
		compStars.DrawStar(g);
		if(laserWeapon.getShoot()==false) {
			laserWeapon.setPosX(spaceCraft.getPosX());
			laserWeapon.setPosY(spaceCraft.getPosY());
		}
		laserWeapon.Draw(g);
		spaceCraft.Draw(g);
		
		g.dispose();
		buffer.show();
	}
	
	//************************************************//
	@Override
	public void run() {//2
		// TODO Auto-generated method stub
		gameRunning = true;
		
		while(gameRunning) {
			Draw();
		}
		
	}
	//<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>//Gestione Input
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int keycode = e.getKeyCode();
		switch (keycode) {
			case KeyEvent.VK_LEFT:{
				spaceCraft.stepToLeft();
				break;
			}
			case KeyEvent.VK_RIGHT:{
				spaceCraft.stepToRight();
				break;
			}
			case KeyEvent.VK_S:{
				laserWeapon.setShoot(true);
				//counter.clockBool(100, 10);
				break;
			}
			case KeyEvent.VK_A:{
				laserWeapon.setShoot(false);
			//	counter.clockBool(100, 10);
				break;
			}
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		int posMouse = (e.getPoint().x)-(spaceCraft.getLenght()/2);
		
		if(posMouse>0 && posMouse+spaceCraft.getLenght()+10 <= Lenght) {
			spaceCraft.setPosX(posMouse);
		}
		//System.out.println("Mouse si muove");
        //repaint();
		
	}
	//<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>v<^>

}
