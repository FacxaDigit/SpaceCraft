import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class LaserWeapon extends /*SpaceCraft,*/ Thread {
	
	private boolean shoot;
	private boolean posWeapon = false;//if true = left //if false = right
	
	private int posX;
	private int posY;
	private Features PropWind;
	
	private int cont;
	private int add = 0;

	public LaserWeapon() {
		// TODO Auto-generated constructor stub
	}

	public LaserWeapon(int posX, int posY, Features PropWind) {
		super();
		// TODO Auto-generated constructor stub
		this.posX = posX;
		this.posY = posY;
		this.PropWind = PropWind;
	}
	//
	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}
	
	public boolean getShoot() {
		return shoot;
	}
	public void setShoot(boolean shoot) {
		this.shoot = shoot;
	}
	//
	
	public void Draw (Graphics g) {
		//
		
		if(shoot == true && (posY - cont)<(PropWind.getHight()+250)) {
			g.setColor(Color.magenta);
			g.fillRect(posX, posY+cont, 4, 25);
			if(posWeapon == false) {
				posWeapon = true;
			}
			else {
				posWeapon = true;
			}
			add++;
			if(add==10) {
				cont--;
				add=0;
			}
			
			System.out.println("Spara");
		}
		else {
			shoot = false;
			cont=0;
		}
	}

}
