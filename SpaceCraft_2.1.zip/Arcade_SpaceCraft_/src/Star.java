import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.lang.System.Logger.Level;
import java.util.logging.Logger;

public class Star {
	
	//private CompStars compStars =;
	
	private int dim;
	private int color;//Possono essere di colore blu, bianco o viola
	
	private int varX;
	private int varY;
	
	public Star() {}
	
	public Star(int dim, int color, int varX, int varY) {
		super();
		this.dim = dim;
		this.color = color;
		this.varX = varX;
		this.varY = varY;
	}
	public Star(Star compStar) {
		super();
		this.dim = compStar.getDim();
		this.color = compStar.getColor();
		this.varX = compStar.getVarX();
		this.varY = compStar.getVarY();
	}

	public int getDim() {
		return dim;
	}

	public void setDim(int dim) {
		this.dim = dim;
	}

	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}

	public int getVarX() {
		return varX;
	}

	public void setVarX(int varX) {
		this.varX = varX;
	}

	public int getVarY() {
		return varY;
	}

	public void setVarY(int varY) {
		this.varY = varY;
	}
	//--------------------------------------------------------------------------

	//--------------------------------------------------------------------------
	
	
}
