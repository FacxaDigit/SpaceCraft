import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.lang.System.Logger.Level;
import java.util.logging.Logger;

public class Counter extends Thread {
	
	private int counter = 0;
	private int watchSpeed;
	
	private int cont;
	/////////////////////////////////////////////////////////////////////////////////
	public Counter() {
		// TODO Auto-generated constructor stub
	}
	
	public Counter(int counter, int watchSpeed) {
		this.counter = counter;
		this.watchSpeed = watchSpeed;
	}
	/////////////////////////////////////////////////////////////////////////////////
	
	
	//----------------------------------------------------------------------------------
	
	public int clockBool(int speed, int timeLimit) {
		for(int k = cont; k<timeLimit; k++) {
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(" Time = " + k);
		}
		return cont;
	}
	
	public int run(int speed, int timeLimit) {
		for(int k = cont; k<timeLimit; k++) {
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(" Time = " + k);
		}
		return cont;
	}

	//---------------------------------------------------------------------------------- Set and get
	
	public int getCounter() {
		return counter;
	}
	
	
	public void setCounter(int counter) {
		this.counter = counter;
	}
	
	
	public int getWatchSpeed() {
		return watchSpeed;
	}
	
	
	public void setWatchSpeed(int watchSpeed) {
		this.watchSpeed = watchSpeed;
	}
	
	//----------------------------------------------------------------------------------

}
