import javax.sound.sampled.*;


public class AudioPlayer {
	
	private String answer;
	private Clip clip;

	
	
	public AudioPlayer(String answer, Clip clip) {
		super();
		this.answer = answer;
		this.clip = clip;
	}


	public void PlayStopReset (String answer) {
		while(!answer.equals("Q")) {
			System.out.println("P = play, S = Stop, R = Reset, Q = Quit");
			System.out.print("Enter your choice: ");
			
			answer = answer.toUpperCase();
			
			switch(answer) {
				case ("P"): clip.start();
					break;
				case ("S"): clip.stop();
					break;
				case ("R"): clip.setMicrosecondPosition(0);
					break;
				case ("Q"): clip.close();
					break;
				case("SR"): {
					clip.stop();
					clip.setMicrosecondPosition(0);
					break;
				}
				default: System.out.println("Not a valid response");
			}
		 }
		
	}
	
}