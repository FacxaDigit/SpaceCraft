import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension; //|Creazione finestra| Per la dimensione della finestra
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.JFrame; //|Creazione finestra| Nome alla finestra

public class Features extends Canvas implements KeyListener, MouseMotionListener, Runnable {
	
	private static final int Lenght = 1920;
	private static final int Hight = 1080;
	
	private static final String NameGame = " ArcadeSpaceCraft ";
	
	private boolean gameRunning = false;
	
	//
	private SpaceCraft spaceCraft;
	private Star star;
	//private Star star2;
	//
	//{
	BufferedImage background = null;
	BufferedImage SpaceCraft = null;
	//BufferedImage Star = null;
	BufferedImage LaserWeapon = null;
	
	File file = null;//audio
	//}
	
	public Features () {
		SourceLoader();
		startGame();
	}

	public static void main(String[] args) {
		
		Features game = new Features();
		
		JFrame windowsGame = new JFrame(NameGame);
		Dimension WindowSize = new Dimension(Lenght, Hight);
		windowsGame.setPreferredSize(WindowSize);
		windowsGame.setMaximumSize(WindowSize);
		windowsGame.setResizable(false);	
		
		windowsGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		windowsGame.add(game);
		windowsGame.addKeyListener(game);
		game.addMouseMotionListener(game);
		
		windowsGame.pack();
		windowsGame.setVisible(true);
		//Creazione thread v
		Thread threadGame = new Thread(game);
		threadGame.start();//Starta il metodo "run" 
		
	}
    public int NumRandom (int varMin, int varMax) {
		int rand = (int) (Math.random() * ((varMax-varMin)+1)) + varMin;
		System.out.println(" Rand = " + rand);
		
        return rand;
    }
	
	public static int getLenght() {
		return Lenght;
	}

	public static int getHight() {
		return Hight;
	}

	private void startGame () {
		spaceCraft = new SpaceCraft(SpaceCraft, 128, 160, 10, 800, this);
		spaceCraft.start();
		star = new Star(/*Star,*/ 10, 200, 30, Lenght, Hight);
		//star2 = new Star(/*Star,*/ 10, 200, 30, Lenght, Hight);
		star.GenerateStarBG();
		//star.start();
		
	}
	
	private void SourceLoader() {
		//immagini
		ImageLoader loader = new ImageLoader();
		background = loader.LoadImage("/Image/SpazioGame.png");
		SpaceCraft = loader.LoadImage("/Image/NavicellaArcade.png");
		
		//audio
		file = new File("Level_Up.wav");
		
		System.out.println("Risorse caricate!");
	}
	private void Draw() {
		BufferStrategy buffer = this.getBufferStrategy();
		if(buffer == null) {
			createBufferStrategy(2);
			return;
		}
		Graphics g = buffer.getDrawGraphics();
		
		g.drawImage(background, 0, 0, Lenght, Hight, this);
		
		star.DrawStar(g);
		spaceCraft.Draw(g);
		
		/*
		g.setColor(Color.white);
		for(int k=0; k<4; k++) {
			varX[k] = NumRandom(1000, 0);
			varY[k] = NumRandom(1000, 0);
			System.out.println("Generazione stelle");
		}
	   	for(int k=0; k<4; k++) {
    		
				g.fillRect(varX[k], varY[k], 2, 2);
	    	}
		
		//g.setColor(Color.white);
		*/
		g.dispose();
		buffer.show();
	}
	
	///////////////////////////////////////////////////////////////////////
	@Override
	public void run() {
		// TODO Auto-generated method stub
		gameRunning = true;
		
		while(gameRunning) {
			Draw();
		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int keycode = e.getKeyCode();
		switch (keycode) {
			case KeyEvent.VK_LEFT:{
				spaceCraft.stepToLeft();
				break;
			}
			case KeyEvent.VK_RIGHT:{
				spaceCraft.stepToRight();
				break;
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		int posMouse = (e.getPoint().x)-(spaceCraft.getLenght()/2);
		
		if(posMouse>0 && posMouse+spaceCraft.getLenght()+10 <= Lenght) {
			spaceCraft.setPosX(posMouse);
		}
		System.out.println("Mouse si muove");
        //repaint();
		
	}


}
