import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Star /*extends Thread*/{
	
	int spostamento = 0;
	int spost = 0;
	private boolean StarBackG = true;
	
	private int windLenght;
	private int windHight;
	
	private int dim;
	private int num;
	private int range;
	
	private int varX[] = new int[450];
	private int varY[] = new int[450];

	//private Graphics g;
	
	//BufferedImage Star;
	
	public Star(/*BufferedImage Star,*/ int dim, int num, int range, int windLenght, int windHight/*, int[] varX, int[] varY*/) {
		super();
		//this.Star = Star;
		this.dim = dim;
		this.num = num;
		this.range = range;
		this.windLenght = windLenght;
		this.windHight = windHight;
		//this.varX = varX;
		//this.varY = varY;
	}
	
    public int NumRandom (int varMin, int varMax) {
		int rand = (int) (Math.random() * ((varMax-varMin)+1)) + varMin;
		System.out.println(" Rand = " + rand + " num = " + num + " varMin = " + varMin + " varMax = " + varMax);
		
        return rand;
    }
	
	public void GenerateStarBG () {
		for(int k=0; k<num; k++) {
			varX[k] = NumRandom(windLenght, 0);
			varY[k] = NumRandom(windHight, 0);
			System.out.println("Generazione stelle");
		}
		
	}
	
	public void DrawStar(Graphics g) {
		spostamento++;
		if(spostamento>10) {
			spost++;
			spostamento=0;
		}
		
		g.setColor(Color.white);
		/*try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
    	for(int k=0; k<num; k++) {
    			g.fillRect(varX[k], varY[k] + spost, 3, 3);
    			System.out.println("spost = " + spost);
			//System.out.println("Disegno stelle  X = " + varX[k] + " Y = "+ varY[k]);
    	}
    	for(int k=0; k<num; k++) {
			g.fillRect(varX[k], varY[k] - (windHight - spost), 3, 3);
		//System.out.println("Disegno stelle  X = " + varX[k] + " Y = "+ varY[k]);
    	}
    	spostamento++;
    	if(spost>windHight) {
    		spost=0;
    	}
    	System.out.println(" spost = " + spost);
	}
	
	
	
	
	
	
	
	
	

}
