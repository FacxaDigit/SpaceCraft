import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.lang.System.Logger.Level;
import java.util.logging.Logger;

public class SpaceCraft extends Thread {
	
	private int posX;
	private int posY;
	
	private int lenght;
	private int hight;
	
	private boolean active;	
	private int step = 10;
	
	BufferedImage imgSpaceCraft;
	Features PropWind;
	
	public SpaceCraft() {}
	public SpaceCraft(BufferedImage image, int lenght, int hight, int posX, int posY, Features PropWind) {
		// TODO Auto-generated constructor stub
		this.posX = posX;
		this.posY = posY;
		this.lenght = lenght;
		this.hight = hight;
		this.imgSpaceCraft = image;
		//active = true;
		this.PropWind = PropWind;
	}
	
	public void Draw (Graphics g) {
		g.drawImage(imgSpaceCraft, posX, posY, lenght, hight, null);
	}
	
	//---------------------------------------------------------------------------------- Set and get
	public int getPosX() {
		return posX;
	}
	public void setPosX(int posX) {
		this.posX = posX;
	}
	public int getPosY() {
		return posY;
	}
	public void setPosY(int posY) {
		this.posY = posY;
	}
	public int getLenght() {
		return lenght;
	}
	public void setLenght(int lenght) {
		this.lenght = lenght;
	}
	public int getHight() {
		return hight;
	}
	public void setHight(int hight) {
		this.hight = hight;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	//----------------------------------------------------------------------------------
	
	public void stepToRight() {
		if((posX+lenght)<PropWind.getLenght()) {
			posX+=step;
			System.out.println("Destra");
		}
		
	}
	public void stepToLeft() {
		if(posX>0) {
			posX-=step;
			System.out.println("Sinistra");
		}
		
	}

}
